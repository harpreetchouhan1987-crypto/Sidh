SIDHU FM — MOBILE WEB APP / PWA PROTOTYPE

1. Extract this ZIP.
2. For a normal preview, open index.html in Chrome.
3. For the real “Install app / Add to Home Screen” PWA experience, host these files on an HTTPS website, then open that website in Chrome on Android.
4. This is an original prototype. Add only audio you own or have permission/licensing to use.
5. It is not an APK. An APK requires an Android build step.
